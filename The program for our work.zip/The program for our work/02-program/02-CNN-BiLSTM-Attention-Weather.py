import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import mean_squared_error, mean_absolute_error

# Load spatial distance data
distance = pd.read_csv('../01-data/spatial_distance_matrix.csv')
adjacency_matrix = distance.values

# Define constants
num_locations_start = 578
num_locations_end = 17 * 17  # Assuming this is the correct reshaping
hours = 100
n_hours = 6
n_features = num_locations_start * num_locations_end
split_ratio = 0.8

# Load inputs and outputs
inputs = np.load('../01-data/04-inputs_data_100_6_578_289.npy')
outputs = np.load('../01-data/04-output_data_100_1_578_289.npy')

# Load weather data
weather = np.load('../01-data/04-weather_data_100_6_15.npy')
num_weather_features = weather.shape[2]
weather_torch = torch.from_numpy(weather).float()

# Preprocessing for model
n_predictions = 1  # Predicting 1 future timestep
samples = hours - n_hours - (n_predictions - 1)
inputs = torch.from_numpy(inputs).float()
outputs = torch.from_numpy(outputs).float()

# Split data
train_size = int(split_ratio * samples)
test_size = samples - train_size
train_inputs = inputs[:train_size]
train_outputs = outputs[:train_size]
test_inputs = inputs[train_size:]
test_outputs = outputs[train_size:]
train_weather = weather_torch[:train_size]
test_weather = weather_torch[train_size:]


class SpatioTemporalModelWithAttention(nn.Module):
    def __init__(self, adjacency_matrix, hidden_dim=50):
        super(SpatioTemporalModelWithAttention, self).__init__()

        self.hidden_dim = hidden_dim

        # Convolutional layer for spatio-temporal data
        self.spatial_conv = nn.Conv3d(1, 1, kernel_size=(3, 3, 3), padding=1)

        # LSTM layer
        self.lstm = nn.LSTM(input_size=n_features, hidden_size=hidden_dim, num_layers=3, batch_first=True,
                            bidirectional=True)

        # Attention layer
        self.attention = nn.Linear(hidden_dim * 2 + num_weather_features, 1)

        # Fully connected layer for output
        self.fc = nn.Linear(hidden_dim * 2 + num_weather_features, n_features * n_predictions)

    def forward(self, x, wea):
        x = x.reshape(-1, n_hours, num_locations_start * num_locations_end)
        x = x.unsqueeze(1)
        x = x.unsqueeze(1)
        x = self.spatial_conv(x)
        x = x.squeeze(1)
        x = x.reshape(-1, n_hours, n_features)

        lstm_out, _ = self.lstm(x)

        # Ensure weather data has the correct shape [batch_size, sequence_length, num_weather_features]
        weather_output = wea  # Assuming wea is already [batch_size, sequence_length, num_weather_features]

        # Concatenate along the feature dimension (dim=2)
        lstm_weather_concat = torch.cat((lstm_out, weather_output), dim=2)
        attention_weights = torch.softmax(self.attention(lstm_weather_concat), dim=1)
        context = torch.sum(attention_weights * lstm_weather_concat, dim=1)
        output = self.fc(context)
        return output.reshape(-1, num_locations_start * num_locations_end * n_predictions)


# Calculate MAPE
def mean_absolute_percentage_error(y_true, y_pred):
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    non_zero_index = (y_true != 0)
    return np.mean(np.abs((y_true[non_zero_index] - y_pred[non_zero_index]) / y_true[non_zero_index])) * 100


# Initialize model, optimizer, and loss function
model = SpatioTemporalModelWithAttention(adjacency_matrix)
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
loss_fn = nn.MSELoss()

# Training loop
for epoch in range(3):
    model.train()
    optimizer.zero_grad()
    outputs_pred = model(train_inputs, train_weather)
    loss = loss_fn(outputs_pred, train_outputs)
    loss.backward()
    optimizer.step()

    if epoch % 2 == 0:
        model.eval()
        with torch.no_grad():
            predictions = model(test_inputs, test_weather)
            mse = mean_squared_error(test_outputs.numpy().flatten(), predictions.numpy().flatten())
            mae = mean_absolute_error(test_outputs.numpy().flatten(), predictions.numpy().flatten())
            rmse = np.sqrt(mse)
            mape = mean_absolute_percentage_error(test_outputs.numpy().flatten(), predictions.numpy().flatten())
            print('Epoch: {}, Loss: {:.4f}, MSE: {:.4f}, MAE: {:.4f}, RMSE: {:.4f}, MAPE: {:.2f}%'.format(epoch,
                                                                                                          loss.item(),
                                                                                                          mse, mae,
                                                                                                          rmse, mape))

print('Training complete.')

output_one_hour_predictions_result = pd.DataFrame(outputs_pred.detach().numpy().reshape(-1, n_features))
output_one_hour_predictions_result.to_csv('output_one_hour_predictions_result.csv', index=False, header=None)