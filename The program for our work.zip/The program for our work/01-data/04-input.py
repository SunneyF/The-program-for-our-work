import pandas as pd
import numpy as np
#distance = pd.read_csv('spatial_distance_matrix.csv')
hourly_trip_counts = np.load("trip_count_100_578_289.npy")
# Define constants
num_locations_start = 578
num_locations_end = 17*17
hours = 100
n_hours = 6
n_features = num_locations_start * num_locations_end
split_ratio = 0.8
# Preprocessing for model
samples = len(hourly_trip_counts) - n_hours - 2+2
inputs = np.zeros((samples, n_hours, n_features))
outputs = np.zeros((samples, 3-2, n_features))

print('1')
for i in range(samples):
    #weather[i] = weather_array_encoded[i:i + n_hours].reshape(n_hours, -1)
    inputs[i] = hourly_trip_counts[i:i + n_hours].reshape(n_hours, -1)
    outputs[i] = hourly_trip_counts[i + n_hours:i + n_hours + 3 - 2].reshape(3 - 2, -1)
#np.save('weather_data_3522_6_20.npy', weather)
print(inputs.shape)
print(outputs.shape)
np.save('04-inputs_data_100_6_578_289.npy', inputs)
np.save('04-output_data_100_1_578_289.npy', outputs)
print('finish')
